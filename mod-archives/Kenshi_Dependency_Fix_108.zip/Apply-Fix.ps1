# Windows PowerShell 5.1. Offline header-only repairs for the supplied mod files.
param(
    [string] $RootPath = '',
    [switch] $NoPause
)

Set-StrictMode -Version 2.0
$ErrorActionPreference = 'Stop'

function Get-BytesSha256 {
    param([Parameter(Mandatory = $true)][byte[]] $Bytes)
    $sha = [Security.Cryptography.SHA256]::Create()
    try {
        return [BitConverter]::ToString($sha.ComputeHash($Bytes)).Replace('-', '').ToLowerInvariant()
    }
    finally { $sha.Dispose() }
}

function Assert-HashText {
    param([string] $Value, [string] $Label)
    if ($Value -notmatch '^[0-9a-fA-F]{64}$') {
        throw "Invalid SHA-256 in patch-plan.json: $Label"
    }
}

function Get-SafeModPath {
    param([string] $Root, [string] $WorkshopId, [string] $Filename)
    if ($WorkshopId -notmatch '^\d+$') { throw 'Invalid Workshop ID in patch plan.' }
    if ([string]::IsNullOrWhiteSpace($Filename) -or
        [IO.Path]::GetFileName($Filename) -cne $Filename -or
        $Filename.IndexOfAny([IO.Path]::GetInvalidFileNameChars()) -ge 0 -or
        [IO.Path]::GetExtension($Filename) -ine '.mod') {
        throw 'Invalid mod filename in patch plan.'
    }
    return [IO.Path]::Combine($Root, $WorkshopId, $Filename)
}

function Resolve-TargetModPath {
    param([string] $Root, [string] $WorkshopId, [string] $Filename)
    $workshopPath = Get-SafeModPath $Root $WorkshopId $Filename
    $stem = [IO.Path]::GetFileNameWithoutExtension($Filename)
    $localPath = [IO.Path]::Combine($Root, $stem, $Filename)
    $workshopExists = [IO.File]::Exists($workshopPath)
    $localExists = [IO.File]::Exists($localPath)
    if ($workshopExists -and $localExists) {
        throw "Ambiguous mod copies found under the selected folder: $workshopPath AND $localPath"
    }
    if ($workshopExists) { return $workshopPath }
    if ($localExists) { return $localPath }
    # Callers decide whether a missing file is required or informational.
    return $workshopPath
}

function New-PatchedBytes {
    param([byte[]] $Original, $Patch)
    if ($Original.Length -lt 8 -or [BitConverter]::ToInt32($Original, 0) -ne 17) {
        throw "Not the expected Kenshi filetype 17: $($Patch.filename)"
    }
    $start = [long]$Patch.replace_start
    $end = [long]$Patch.replace_end
    $before = [long]$Patch.offset4_before
    $after = [long]$Patch.offset4_after
    $replacement = [Convert]::FromBase64String([string]$Patch.replacement_base64)
    if ($start -lt 8 -or $end -lt $start -or $end -gt $Original.Length -or
        $before -lt 0 -or $before -gt [int]::MaxValue -or
        $after -lt 0 -or $after -gt [int]::MaxValue -or
        $end -gt ($before + 12) -or ($before + 16) -gt $Original.Length) {
        throw "Invalid header replacement range: $($Patch.filename)"
    }
    if ([BitConverter]::ToInt32($Original, 4) -ne $before) {
        throw "Original header offset does not match the plan: $($Patch.filename)"
    }
    $delta = [long]$replacement.Length - ($end - $start)
    if ($after -ne ($before + $delta)) {
        throw "Replacement header offset is inconsistent: $($Patch.filename)"
    }
    $length = [long]$Original.Length + $delta
    if ($length -lt 8 -or $length -gt [int]::MaxValue -or ($after + 16) -gt $length) {
        throw "Invalid patched file length: $($Patch.filename)"
    }
    $candidate = [byte[]]::new([int]$length)
    [Array]::Copy($Original, 0, $candidate, 0, [int]$start)
    [Array]::Copy($replacement, 0, $candidate, [int]$start, $replacement.Length)
    [Array]::Copy($Original, [int]$end, $candidate, [int]($start + $replacement.Length),
                  [int]($Original.Length - $end))
    [Array]::Copy([BitConverter]::GetBytes([int]$after), 0, $candidate, 4, 4)
    if ((Get-BytesSha256 -Bytes $candidate) -ine [string]$Patch.patched_sha256) {
        throw "Patched SHA-256 does not match the plan: $($Patch.filename)"
    }
    # A comma prevents PowerShell from enumerating the byte array on return.
    return ,$candidate
}

$written = [Collections.Generic.List[object]]::new()
$backupRoot = $null
$completed = $false
try {
    if ($PSVersionTable.PSVersion -lt [version]'5.1') {
        throw 'Windows PowerShell 5.1 or later is required.'
    }
    if (-not [BitConverter]::IsLittleEndian) {
        throw 'This installer requires a little-endian Windows computer.'
    }
    $planPath = Join-Path $PSScriptRoot 'patch-plan.json'
    if (-not [IO.File]::Exists($planPath)) { throw 'patch-plan.json is missing beside Apply-Fix.ps1.' }
    $plan = [IO.File]::ReadAllText($planPath, [Text.Encoding]::UTF8) | ConvertFrom-Json
    if ([int]$plan.schema_version -ne 1) { throw 'Unsupported patch plan schema.' }
    $patches = @($plan.patches)
    if ($patches.Count -ne 5) { throw 'Expected exactly five mod repairs in the supplied plan.' }

    # Only these five supplied mods may be changed. A modified plan cannot add targets.
    $allowed = @{
        '1971937665' = 'Legendary of Kenshi - MC and MCA patch.mod'
        '1975848555' = 'Legendary of Kenshi_custom races patches.mod'
        '3255348303' = 'Hydraulic Knight Equipment RU.mod'
        '3536543629' = 'DigCombat Skelemations2.mod'
        '3536546347' = 'Great_Anim Skelemation2.mod'
    }
    $seen = @{}
    foreach ($patch in $patches) {
        $id = [string]$patch.workshop_id
        $filename = [string]$patch.filename
        if (-not $allowed.ContainsKey($id) -or $allowed[$id] -cne $filename -or $seen.ContainsKey($id)) {
            throw 'Patch plan contains an unexpected or duplicate mod target.'
        }
        $seen[$id] = $true
        Assert-HashText ([string]$patch.original_sha256) "$filename original"
        Assert-HashText ([string]$patch.patched_sha256) "$filename patched"
        if ([string]$patch.original_sha256 -ieq [string]$patch.patched_sha256) {
            throw "Original and patched hashes must differ: $filename"
        }
    }

    Write-Host 'Kenshi dependency header repair - offline, no administrator rights requested.'
    Write-Host 'All five files are checked before any original file is changed.'
    if ([string]::IsNullOrWhiteSpace($RootPath)) {
        Write-Host 'Select Steam workshop\content\233860 OR the local Kenshi\mods folder.'
        Add-Type -AssemblyName System.Windows.Forms
        $picker = [Windows.Forms.FolderBrowserDialog]::new()
        try {
            $picker.Description = 'Select Steam workshop\content\233860 OR Kenshi\mods (local mod folders)'
            $picker.ShowNewFolderButton = $false
            if ($picker.ShowDialog() -ne [Windows.Forms.DialogResult]::OK) {
                Write-Host 'Cancelled. No files changed.'
                exit 0
            }
            $root = [IO.Path]::GetFullPath($picker.SelectedPath)
        }
        finally { $picker.Dispose() }
    }
    else { $root = [IO.Path]::GetFullPath($RootPath) }
    if (-not [IO.Directory]::Exists($root)) { throw "Selected folder does not exist: $root" }

    $preflight = [Collections.Generic.List[object]]::new()
    foreach ($patch in $patches) {
        $target = Resolve-TargetModPath $root ([string]$patch.workshop_id) ([string]$patch.filename)
        if (-not [IO.File]::Exists($target)) {
            throw "Required file not found. Select the 233860 or Kenshi\mods folder containing all five mods: $target"
        }
        $original = [IO.File]::ReadAllBytes($target)
        $hash = Get-BytesSha256 -Bytes $original
        if ($hash -ieq [string]$patch.patched_sha256) {
            $preflight.Add([pscustomobject]@{
                Patch = $patch; Target = $target; Status = 'Already fixed'
                Original = $original; Candidate = $null; OriginalHash = $hash; Backup = $null
            })
            Write-Host "Already fixed: $($patch.filename)"
        }
        elseif ($hash -ieq [string]$patch.original_sha256) {
            $candidate = New-PatchedBytes -Original $original -Patch $patch
            $preflight.Add([pscustomobject]@{
                Patch = $patch; Target = $target; Status = 'Ready'
                Original = $original; Candidate = $candidate; OriginalHash = $hash; Backup = $null
            })
            Write-Host "Verified original: $($patch.filename)"
        }
        else {
            throw "Unknown or updated file version: $target`nSHA-256: $hash`nNothing has been patched. Do not force this repair onto a different version."
        }
    }

    # The Gym file is informational only and is never changed or required to apply this repair.
    foreach ($item in @($plan.unchanged)) {
        $check = Resolve-TargetModPath $root ([string]$item.workshop_id) ([string]$item.filename)
        Assert-HashText ([string]$item.sha256) ([string]$item.filename)
        if ([IO.File]::Exists($check)) {
            $checkHash = Get-BytesSha256 -Bytes ([IO.File]::ReadAllBytes($check))
            if ($checkHash -ieq [string]$item.sha256) {
                Write-Host "Verified; kept unchanged: $($item.filename)"
            }
            else {
                Write-Host "Different version; kept unchanged: $($item.filename)"
            }
        }
        else { Write-Host "Not found; not required and not changed: $($item.filename)" }
    }

    $pending = @($preflight | Where-Object { $_.Status -eq 'Ready' })
    if ($pending.Count -eq 0) {
        Write-Host 'All five repairs are already installed. No files changed.'
        $completed = $true
        exit 0
    }

    # Detect a Steam update or concurrent edit after the preflight, before making backups.
    foreach ($entry in $preflight) {
        if ((Get-BytesSha256 -Bytes ([IO.File]::ReadAllBytes($entry.Target))) -ine $entry.OriginalHash) {
            throw "A mod changed during the checks. Close Steam updates and retry: $($entry.Target)"
        }
    }

    $stamp = [DateTime]::Now.ToString('yyyyMMdd_HHmmss')
    $suffix = [Guid]::NewGuid().ToString('N').Substring(0, 8)
    $backupRoot = Join-Path $root ("_KenshiDependencyFix_Backup_{0}_{1}" -f $stamp, $suffix)
    [IO.Directory]::CreateDirectory($backupRoot) | Out-Null
    # Every pending original is backed up and verified BEFORE the first target write.
    foreach ($entry in $pending) {
        $backup = Get-SafeModPath $backupRoot ([string]$entry.Patch.workshop_id) ([string]$entry.Patch.filename)
        [IO.Directory]::CreateDirectory([IO.Path]::GetDirectoryName($backup)) | Out-Null
        [IO.File]::WriteAllBytes($backup, $entry.Original)
        if ((Get-BytesSha256 -Bytes ([IO.File]::ReadAllBytes($backup))) -ine $entry.OriginalHash) {
            throw "Backup verification failed: $backup"
        }
        $entry.Backup = $backup
    }
    $backupFiles = @($pending | ForEach-Object {
        [ordered]@{
            target_path = $_.Target
            backup_path = $_.Backup
            workshop_id = [string]$_.Patch.workshop_id
            filename = [string]$_.Patch.filename
            original_sha256 = $_.OriginalHash
            patched_sha256 = [string]$_.Patch.patched_sha256
        }
    })
    $backupManifest = [ordered]@{
        schema_version = 1
        created_utc = [DateTime]::UtcNow.ToString('o')
        selected_root = $root
        files = $backupFiles
    } | ConvertTo-Json -Depth 5
    [IO.File]::WriteAllText((Join-Path $backupRoot 'backup-manifest.json'), $backupManifest,
                            [Text.UTF8Encoding]::new($false))
    Write-Host "Backups verified: $backupRoot"

    foreach ($entry in $pending) {
        if ((Get-BytesSha256 -Bytes ([IO.File]::ReadAllBytes($entry.Target))) -ine $entry.OriginalHash) {
            throw "A mod changed before writing. Repair stopped: $($entry.Target)"
        }
        # Register before writing so even a partially failed write is rolled back.
        $written.Add($entry)
        [IO.File]::WriteAllBytes($entry.Target, [byte[]]$entry.Candidate)
        if ((Get-BytesSha256 -Bytes ([IO.File]::ReadAllBytes($entry.Target))) -ine [string]$entry.Patch.patched_sha256) {
            throw "Verification failed after writing: $($entry.Target)"
        }
        Write-Host "Patched and verified: $($entry.Patch.filename)"
    }
    $completed = $true
    Write-Host ''
    Write-Host 'Done. Only the five planned .mod headers were repaired.'
    Write-Host 'The Gym mod and game assets were not changed.'
    Write-Host "Keep this backup folder: $backupRoot"
    Write-Host 'Steam may replace local Workshop edits when these mods update.'
    exit 0
}
catch {
    $failure = $_.Exception.Message
    $rollbackFailed = $false
    if ($written.Count -gt 0 -and -not $completed) {
        Write-Host 'An error occurred. Restoring every file touched by this run...'
        for ($index = $written.Count - 1; $index -ge 0; $index--) {
            $entry = $written[$index]
            try {
                if ([IO.File]::Exists($entry.Target) -and
                    (Get-BytesSha256 -Bytes ([IO.File]::ReadAllBytes($entry.Target))) -ieq $entry.OriginalHash) {
                    Write-Host "Already original; verified: $($entry.Patch.filename)"
                    continue
                }
                [IO.File]::WriteAllBytes($entry.Target, [byte[]]$entry.Original)
                if ((Get-BytesSha256 -Bytes ([IO.File]::ReadAllBytes($entry.Target))) -ine $entry.OriginalHash) {
                    throw 'Restored bytes did not pass SHA-256 verification.'
                }
                Write-Host "Restored and verified: $($entry.Patch.filename)"
            }
            catch {
                $rollbackFailed = $true
                Write-Host "RESTORE FAILED: $($entry.Target)" -ForegroundColor Red
                Write-Host "Restore manually from: $($entry.Backup)" -ForegroundColor Red
            }
        }
    }
    Write-Host ''
    Write-Host "Repair stopped: $failure" -ForegroundColor Red
    if ($backupRoot) { Write-Host "Backup folder retained: $backupRoot" }
    if ($written.Count -eq 0) { Write-Host 'No original mod files were changed.' }
    elseif (-not $rollbackFailed) { Write-Host 'All files touched by this run were restored to their original bytes.' }
    exit 1
}
