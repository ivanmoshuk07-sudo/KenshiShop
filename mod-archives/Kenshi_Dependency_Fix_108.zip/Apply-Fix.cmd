@echo off
setlocal
set "FIX_PAUSE=1"
if /I "%~1"=="-NoPause" set "FIX_PAUSE=0"
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -STA -File "%~dp0Apply-Fix.ps1" %*
set "FIX_EXIT=%ERRORLEVEL%"
echo.
if "%FIX_PAUSE%"=="1" pause
exit /b %FIX_EXIT%
