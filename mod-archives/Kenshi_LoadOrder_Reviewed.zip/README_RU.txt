KENSHI — ПРОВЕРКА ПОРЯДКА МОДОВ

В архиве:
  mods.cfg          — исправленный порядок
  mods.original.cfg — точная копия присланного файла
  README_RU.txt     — изменения и рекомендации по патчам

Сохранены все 103 исходных мода, включая все три мода вербовки.
Моды не удалялись и не переименовывались. Новые патчи в список не добавлены:
сначала их нужно установить, а затем включить в лаунчере.

УСТАНОВКА ПОРЯДКА
1. Закрой Kenshi и её лаунчер.
2. Сохрани копию текущего Kenshi/data/mods.cfg.
3. Скопируй mods.cfg из этого архива в Kenshi/data/mods.cfg с заменой.
4. Открой лаунчер и проверь, что моды из списка найдены.
Для возврата скопируй mods.original.cfg в Kenshi/data и переименуй в mods.cfg.

ЧТО ПЕРЕСТАВЛЕНО
• Nitoryu.mod перенесён в самый конец — прямое указание автора.
• Let's Talk.mod перенесён выше трёх модов вербовки. Это отдаёт им приоритет
  в пересекающихся изменениях, но не превращает их в полностью совместимую
  единую систему. Все три оставлены по твоему выбору.
• Hydraulic Knight Equipment вместе с тремя патчами перемещён к экипировке,
  перед Legendary of Kenshi. Внутренний порядок блока сохранён:
  оригинал → Shield PATCH → RU → NCE. Автор требует патчи ниже оригинала;
  подтверждённого правила между тремя отдельными патчами нет.
• DigCombat_skill_limits.mod перемещён ниже существующих патчей анимаций,
  чтобы его ограничения навыков имели поздний приоритет.
• NoArmorPenalty, Attack Slots x3, MaxStats500 и 256 Squad Limit размещены
  после остальных изменений, перед Nitoryu.
• KenshiShop_LegendaryCompat остаётся ниже KenshiShop и Legendary of Kenshi,
  как требуется в документации KenshiShop.

РЕКОМЕНДУЕМЫЕ НЕДОСТАЮЩИЕ ПАТЧИ
Это не четыре обязательные зависимости для запуска игры. Первый исправляет
известный дефект; остальные нужны, чтобы установленные анимации работали
также на скелетах Robotics Limb Base Skeletons.

1. Great Animations Mod - Fix for missing animations
   https://steamcommunity.com/sharedfiles/filedetails/?id=3726991126
   Отключает четыре боевых приёма с отсутствующими женскими анимациями.
   Имя файла: Great Animations missing anims disabled.mod.
   Загружать ниже Great Anims Mod и его патчей.

2. Gym Training Tools to Robotics Limb Base Skeletons Patch
   https://steamcommunity.com/sharedfiles/filedetails/?id=2815457355
   Подключает анимации тренажёров к скелетам RLBS.
   Загружать ниже CBT Gym Training Tools и Robotics Limb Base Skeletons.
   Имеющийся CBT Gym Training Tools to Dark Hive этот патч не заменяет.

3. Great Animations mod Skeleton Patches v2
   https://steamcommunity.com/sharedfiles/filedetails/?id=3536546347
   Подключает Great Animations к поддерживаемым скелетам, включая RLBS.
   Загружать ниже Great Anims Mod и Robotics Limb Base Skeletons.
   Остальные перечисленные автором расовые моды не нужно ставить специально.

4. GROUNDED Animation Skeleton Patches v2
   https://steamcommunity.com/sharedfiles/filedetails/?id=3536543629
   Подключает GROUNDED/DigCombatAnimation к скелетам RLBS.
   Загружать ниже DigCombatAnimation и Robotics Limb Base Skeletons,
   но ВЫШЕ DigCombat_skill_limits.mod.

В этом порядке удобное место для новых четырёх патчей — непосредственно
перед DigCombat_skill_limits.mod. Сначала установи патчи и уточни фактические
имена их .mod-файлов в лаунчере; неизвестные имена в mods.cfg не вписаны.

ЧТО НЕ НУЖНО УДАЛЯТЬ ИЛИ ДОСТАВЛЯТЬ ПО ОДНОМУ НАЗВАНИЮ
• Dark Hive_Multi-Animation Mod Compatibility Patch не включает MCA/MC/AO;
  отдельные Dark Hive_MCA/MC/AO-патчи остаются нужны для этих наборов.
• Legendary of Kenshi - MC and MCA patch.mod сохранил старое имя файла,
  но его актуальная страница описывает расширенную поддержку анимаций.
• Родитель Dark Hive_Soldier Gas Mask уже есть: 2PN8HiveSoldiers.mod — это
  Hive Soldiers Expanded. Hive Soldiers++ — другой мод.
• Hydraulic Knight Equipment NCE требует свой оригинал; отсутствие общего
  No Cut Efficiency.mod не является недостающей обязательной зависимостью.
• Для Hydraulic есть объединённый RU + Shield/Helmet + NCE-патч, но это
  необязательная ЗАМЕНА трёх отдельных патчей, а не четвёртый патч поверх них:
  https://steamcommunity.com/sharedfiles/filedetails/?id=3255516351

ОГРАНИЧЕНИЯ ПРОВЕРКИ
Проверены имена и порядок в присланном mods.cfg, опубликованные требования
авторов и совпадение состава до/после. Сами установленные .mod и DLL не
предоставлены: фактические конфликты отдельных полей и версии не проверены,
игра не запускалась. Порядок не устраняет все пересечения содержимого.

Recruitable Prisoners ALL рассчитан автором на ванильных NPC; возможность
нанимать всех NPC дополнительных модов из этого списка не следует.
RecruitPrisoners, ALL и Recruit Anyone пересекаются; их сохранение — твой выбор.
Improved Smithing и Weapon Smithing Expanded тоже пересекаются по назначению;
исходный относительный порядок сохранён, преимущество в общих полях остаётся
у Weapon Smithing Expanded. Обязательный готовый патч для этой пары не найден.

RE_Kenshi устанавливается вне обычного списка .mod, поэтому отсутствие его
строки в mods.cfg нормально. KenshiLua/KEO/Nitoryu используют внешние плагины;
по списку нельзя проверить их установку. Для KEO автор указывает Steam Kenshi
1.0.65 и RE_Kenshi >= 0.3.5, GOG не поддержан. Nitoryu также требует
RE_Kenshi >= 0.3.5; его положение в конце не заменяет установку DLL.

Созданный ранее Mongrel_Duo_100k_10.mod отсутствует в присланном списке.
Если он уже скопирован в mods, включи его в лаунчере среди стартовых модов,
например после Hive Praetorian Starts.mod. В этот файл он не добавлен,
поскольку наличие установленного мода не подтверждено.

ОСНОВНЫЕ ИСТОЧНИКИ
Nitoryu: https://www.nexusmods.com/kenshi/mods/2239?tab=description
GROUNDED: https://steamcommunity.com/sharedfiles/filedetails/?id=2922713981
Dark Hive Multi-Animation:
https://steamcommunity.com/sharedfiles/filedetails/?id=3682526395
Legendary Multi-Animation:
https://steamcommunity.com/sharedfiles/filedetails/?id=1971937665
Legendary Custom Races:
https://steamcommunity.com/sharedfiles/filedetails/?id=1975848555
Hive Soldiers Expanded:
https://steamcommunity.com/sharedfiles/filedetails/?id=1994276293
Hydraulic NCE: https://steamcommunity.com/sharedfiles/filedetails/?id=3255382498
Hydraulic Shield: https://steamcommunity.com/sharedfiles/filedetails/?id=3255498659
Hydraulic RU: https://steamcommunity.com/sharedfiles/filedetails/?id=3255348303
KenshiShop: https://github.com/ivanmoshuk07-sudo/KenshiShop/blob/main/README.md
KEO: https://github.com/jacobericson/KEO/blob/main/README.md
